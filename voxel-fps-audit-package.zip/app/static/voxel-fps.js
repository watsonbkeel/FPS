import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';

const page = document.getElementById('voxel-fps-page');
if (!page) {
  throw new Error('方块战场页面容器不存在');
}

const stage = page.querySelector('[data-voxel-stage]');
const canvas = page.querySelector('[data-voxel-canvas]');
const overlay = page.querySelector('[data-voxel-overlay]');
const gameOverOverlay = page.querySelector('[data-voxel-gameover]');
const respawnOverlay = page.querySelector('[data-voxel-respawn]');
const pauseOverlay = page.querySelector('[data-voxel-pause]');
const startButton = page.querySelector('[data-voxel-start]');
const restartButton = page.querySelector('[data-voxel-restart]');
const forceRestartButton = page.querySelector('[data-voxel-force-restart]');
const resumeButton = page.querySelector('[data-voxel-resume]');
const fullscreenButton = page.querySelector('[data-voxel-fullscreen]');
const timerEl = page.querySelector('[data-voxel-timer]');
const healthEl = page.querySelector('[data-voxel-health]');
const killsEl = page.querySelector('[data-voxel-kills]');
const friendlyEl = page.querySelector('[data-voxel-friendly]');
const enemyEl = page.querySelector('[data-voxel-enemy]');
const statusEl = page.querySelector('[data-voxel-status]');
const resultEl = page.querySelector('[data-voxel-result]');
const endKillsEl = page.querySelector('[data-voxel-end-kills]');
const endTimeEl = page.querySelector('[data-voxel-end-time]');
const endCoinsEl = page.querySelector('[data-voxel-end-coins]');
const endTitleEl = page.querySelector('[data-voxel-end-title]');
const endSummaryEl = page.querySelector('[data-voxel-end-summary]');
const respawnTitleEl = page.querySelector('[data-voxel-respawn-title]');
const respawnSummaryEl = page.querySelector('[data-voxel-respawn-summary]');
const pauseTitleEl = page.querySelector('[data-voxel-pause-title]');
const pauseSummaryEl = page.querySelector('[data-voxel-pause-summary]');
const hitMarker = page.querySelector('[data-hit-marker]');
const damageScreen = page.querySelector('[data-voxel-damage-screen]');
const killfeed = page.querySelector('[data-voxel-killfeed]');
const mobileControls = page.querySelector('[data-voxel-mobile-controls]');
const stickZone = page.querySelector('[data-voxel-stick-zone]');
const stickThumb = page.querySelector('[data-voxel-stick-thumb]');
const mobileFireButton = page.querySelector('[data-voxel-mobile-fire]');

const petId = Number(page.dataset.petId || 0);
const petName = page.dataset.petName || '宠物';
const csrfToken = page.dataset.csrf || '';
const claimUrl = page.dataset.claimUrl || '';

const TEAM_FRIENDLY = 'friendly';
const TEAM_ENEMY = 'enemy';
const ROUND_DURATION = 120;
const PLAYER_HEIGHT = 1.7;
const PLAYER_RADIUS = 0.35;
const MAP_HALF = 36;
const PLAYER_RESPAWN_MS = 4500;
const BOT_RESPAWN_MS = 5200;

const FRIEND_SPAWNS = [
  new THREE.Vector3(-14, 0, 24),
  new THREE.Vector3(-6, 0, 20),
  new THREE.Vector3(6, 0, 20),
  new THREE.Vector3(14, 0, 24),
];

const ENEMY_SPAWNS = [
  new THREE.Vector3(-15, 0, -24),
  new THREE.Vector3(-6, 0, -20),
  new THREE.Vector3(4, 0, -22),
  new THREE.Vector3(13, 0, -18),
  new THREE.Vector3(18, 0, -24),
];

const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
renderer.setSize(stage.clientWidth, stage.clientHeight, false);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
scene.background = new THREE.Color('#8dc6ff');
scene.fog = new THREE.Fog('#8dc6ff', 22, 96);

const camera = new THREE.PerspectiveCamera(72, stage.clientWidth / stage.clientHeight, 0.1, 180);
camera.position.set(0, PLAYER_HEIGHT, 12);

const controls = new PointerLockControls(camera, document.body);
scene.add(controls.getObject());

const ambientLight = new THREE.HemisphereLight(0xffffff, 0x6a4a2f, 1.05);
scene.add(ambientLight);

const sun = new THREE.DirectionalLight(0xffffff, 1.2);
sun.position.set(14, 22, 8);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -28;
sun.shadow.camera.right = 28;
sun.shadow.camera.top = 28;
sun.shadow.camera.bottom = -28;
scene.add(sun);

const mapGroup = new THREE.Group();
scene.add(mapGroup);

const colliders = [];
const coverAnchors = [];
const botState = [];
const playerShots = [];
const keyState = { w: false, a: false, s: false, d: false, space: false };

let playerVelocity = new THREE.Vector3();
let playerHealth = 100;
let playerKills = 0;
let playerAlive = true;
let pointerLocked = false;
let lastFrame = 0;
let elapsed = 0;
let gameRunning = false;
let gamePaused = false;
let gameEnded = false;
let pauseStartedAt = 0;
let roundStart = 0;
let lastPlayerShot = 0;
let hitMarkerTimer = 0;
let damageFlashTimer = 0;
let earnedCoins = 0;
let respawnTimer = 0;
let mobileLookId = null;
let mobileMoveId = null;
let mobileMoveVector = new THREE.Vector2();
let mobileLookLast = null;

window.voxelFpsDebug = {
  get playerPosition() {
    const pos = controls.getObject().position;
    return { x: Number(pos.x.toFixed(3)), y: Number(pos.y.toFixed(3)), z: Number(pos.z.toFixed(3)) };
  },
  get locked() {
    return pointerLocked;
  },
  get paused() {
    return gamePaused;
  },
};

const raycaster = new THREE.Raycaster();
const collisionBox = new THREE.Box3();
const scratchBox = new THREE.Box3();
const tempVecA = new THREE.Vector3();
const tempVecB = new THREE.Vector3();
const tempVecC = new THREE.Vector3();

const materialSet = {
  grass: new THREE.MeshStandardMaterial({ color: '#72b15d', flatShading: true }),
  dirt: new THREE.MeshStandardMaterial({ color: '#7a5a32', flatShading: true }),
  stone: new THREE.MeshStandardMaterial({ color: '#8d8f95', flatShading: true }),
  wall: new THREE.MeshStandardMaterial({ color: '#a98b62', flatShading: true }),
  wallDark: new THREE.MeshStandardMaterial({ color: '#8c6f4c', flatShading: true }),
  blue: new THREE.MeshStandardMaterial({ color: '#4a74c9', flatShading: true }),
  red: new THREE.MeshStandardMaterial({ color: '#c65050', flatShading: true }),
  skin: new THREE.MeshStandardMaterial({ color: '#f1c897', flatShading: true }),
  gun: new THREE.MeshStandardMaterial({ color: '#30353c', flatShading: true }),
  muzzle: new THREE.MeshBasicMaterial({ color: '#ffcb66' }),
};

function addKillfeed(text) {
  const node = document.createElement('div');
  node.className = 'voxel-killfeed-item';
  node.textContent = text;
  killfeed.prepend(node);
  const items = [...killfeed.children];
  items.slice(4).forEach((item) => item.remove());
  window.setTimeout(() => node.remove(), 2200);
}

function setResultMessage(text, tone = 'normal') {
  resultEl.textContent = text;
  resultEl.classList.remove('is-success', 'is-warning');
  if (tone === 'success') resultEl.classList.add('is-success');
  if (tone === 'warning') resultEl.classList.add('is-warning');
}

function setStatus(text) {
  statusEl.textContent = text;
}

function focusGamePage() {
  page.focus({ preventScroll: true });
  window.focus();
}

function clearMovementState() {
  keyState.w = false;
  keyState.a = false;
  keyState.s = false;
  keyState.d = false;
  keyState.space = false;
  mobileMoveVector.set(0, 0);
  resetStick();
}

function setMovementKey(event, pressed) {
  const key = (event.key || '').toLowerCase();
  if (event.code === 'KeyW' || key === 'w') keyState.w = pressed;
  if (event.code === 'KeyA' || key === 'a') keyState.a = pressed;
  if (event.code === 'KeyS' || key === 's') keyState.s = pressed;
  if (event.code === 'KeyD' || key === 'd') keyState.d = pressed;
  if (event.code === 'Space' || key === ' ') {
    if (pressed) {
      event.preventDefault();
    }
    keyState.space = pressed;
  }
}

function setPaused(paused, reason = '战斗已暂停') {
  gamePaused = paused;
  if (paused) {
    clearMovementState();
    pauseStartedAt = performance.now();
    pauseOverlay.hidden = false;
    pauseTitleEl.textContent = '战斗已暂停';
    pauseSummaryEl.textContent = reason;
    setStatus('战斗已暂停，可点击继续游戏恢复。');
  } else {
    if (pauseStartedAt) {
      roundStart += performance.now() - pauseStartedAt;
      pauseStartedAt = 0;
    }
    pauseOverlay.hidden = true;
    if (!gameEnded && gameRunning) {
      setStatus('已重新进入战斗。');
    }
  }
}

function isMobileMode() {
  return window.matchMedia('(hover: none), (pointer: coarse)').matches;
}

function showHitMarker() {
  hitMarker.classList.add('is-active');
  hitMarkerTimer = 120;
}

function createBlock(x, y, z, w, h, d, material, collider = true) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mapGroup.add(mesh);
  if (collider) {
    const box = new THREE.Box3().setFromObject(mesh);
    colliders.push(box);
  }
  return mesh;
}

function createArena() {
  mapGroup.clear();
  colliders.length = 0;
  coverAnchors.length = 0;

  createBlock(0, -0.5, 0, MAP_HALF * 2, 1, MAP_HALF * 2, materialSet.grass, false);

  const wallSegments = [
    { x: 0, y: 2.5, z: -MAP_HALF, w: MAP_HALF * 2, h: 5, d: 2 },
    { x: 0, y: 2.5, z: MAP_HALF, w: MAP_HALF * 2, h: 5, d: 2 },
    { x: -MAP_HALF, y: 2.5, z: 0, w: 2, h: 5, d: MAP_HALF * 2 },
    { x: MAP_HALF, y: 2.5, z: 0, w: 2, h: 5, d: MAP_HALF * 2 },
  ];
  wallSegments.forEach((part) => createBlock(part.x, part.y, part.z, part.w, part.h, part.d, materialSet.wall));

  for (let i = -(MAP_HALF - 4); i <= MAP_HALF - 4; i += 4) {
    createBlock(i, 5.5, -MAP_HALF, 2, 1, 2, materialSet.wallDark);
    createBlock(i, 5.5, MAP_HALF, 2, 1, 2, materialSet.wallDark);
    createBlock(-MAP_HALF, 5.5, i, 2, 1, 2, materialSet.wallDark);
    createBlock(MAP_HALF, 5.5, i, 2, 1, 2, materialSet.wallDark);
  }

  for (const x of [-26, 0, 26]) {
    for (const z of [-26, 26]) {
      createBlock(x, 4.5, z, 4, 9, 4, materialSet.wallDark);
    }
  }

  const covers = [
    [-18, 1, -18], [-8, 1, -20], [4, 1, -18], [16, 1, -16],
    [-20, 1, -4], [-10, 1, -2], [0, 1, -6], [10, 1, -1], [18, 1, -4],
    [-22, 1, 10], [-12, 1, 6], [-2, 1, 10], [8, 1, 6], [18, 1, 12],
    [-16, 1, 20], [-4, 1, 18], [8, 1, 20], [20, 1, 18],
    [-24, 1, 0], [24, 1, 0], [0, 1, 0],
  ];
  covers.forEach(([x, y, z]) => {
    createBlock(x, y, z, 2, 2, 2, materialSet.stone);
    createBlock(x, y + 1.5, z, 2, 1, 2, materialSet.dirt);
    coverAnchors.push(new THREE.Vector3(x, 0, z));
  });

  const tallCovers = [
    [-14, 2, 12], [14, 2, 10], [-12, 2, -12], [12, 2, -10],
    [-8, 2, 16], [8, 2, 16], [0, 2, -14],
  ];
  tallCovers.forEach(([x, y, z]) => {
    createBlock(x, y, z, 3, 4, 3, materialSet.stone);
    coverAnchors.push(new THREE.Vector3(x, 0, z));
  });
}

function makeVoxelHumanoid(team, isPlayer = false) {
  const root = new THREE.Group();
  const bodyMat = team === TEAM_FRIENDLY ? materialSet.blue : materialSet.red;

  const head = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.5, 0.5), materialSet.skin);
  head.position.set(0, 1.5, 0);

  const body = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.8, 0.35), bodyMat);
  body.position.set(0, 1.0, 0);

  const armL = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.7, 0.18), bodyMat);
  const armR = armL.clone();
  armL.position.set(-0.42, 1.0, 0);
  armR.position.set(0.42, 1.0, 0);

  const legL = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.7, 0.2), bodyMat);
  const legR = legL.clone();
  legL.position.set(-0.15, 0.25, 0);
  legR.position.set(0.15, 0.25, 0);

  const gun = new THREE.Group();
  const stock = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.15, 0.35), materialSet.gun);
  stock.position.set(0, 0, -0.12);
  const receiver = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 0.55), materialSet.gun);
  receiver.position.set(0, 0, 0.15);
  const barrel = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 0.7), materialSet.gun);
  barrel.position.set(0, 0, 0.72);
  const grip = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.22, 0.1), materialSet.gun);
  grip.position.set(0, -0.18, 0.1);
  gun.add(stock, receiver, barrel, grip);
  gun.position.set(0.26, 1.05, 0.25);
  gun.rotation.x = Math.PI * 0.08;
  gun.rotation.y = Math.PI * 0.02;

  const muzzle = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.18, 0.18), materialSet.muzzle);
  muzzle.position.set(0, 0, 1.08);
  muzzle.visible = false;
  gun.add(muzzle);

  root.add(head, body, armL, armR, legL, legR, gun);
  root.castShadow = true;
  root.userData = { head, body, armL, armR, legL, legR, gun, muzzle, team, isPlayer };
  return root;
}

function createViewWeapon() {
  const gun = new THREE.Group();
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.16, 0.8), materialSet.gun);
  body.position.set(0, 0, -0.25);
  const barrel = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 0.7), materialSet.gun);
  barrel.position.set(0.06, 0.03, -0.95);
  const stock = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.18, 0.26), materialSet.gun);
  stock.position.set(-0.02, -0.05, 0.08);
  const hand = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.18, 0.16), materialSet.skin);
  hand.position.set(-0.08, -0.16, -0.05);
  const muzzle = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 0.14), materialSet.muzzle);
  muzzle.position.set(0.06, 0.03, -1.34);
  muzzle.visible = false;
  gun.add(body, barrel, stock, hand, muzzle);
  gun.position.set(0.46, -0.38, -0.75);
  gun.rotation.set(-0.12, -0.12, 0.04);
  gun.userData = { muzzle, kick: 0 };
  camera.add(gun);
  return gun;
}

const viewWeapon = createViewWeapon();

function makeBot(team, index, spawn) {
  const mesh = makeVoxelHumanoid(team);
  mesh.position.copy(spawn);
  mesh.position.y = 0;
  scene.add(mesh);

  return {
    id: `${team}-${index}`,
    team,
    mesh,
    hp: 100,
    alive: true,
    state: 'patrol',
    deadAt: 0,
    respawnAt: 0,
    cooldown: 400 + Math.random() * 800,
    patrolTarget: spawn.clone(),
    coverTarget: null,
    strafeDir: Math.random() > 0.5 ? 1 : -1,
    strafeTimer: 500 + Math.random() * 900,
    burstLeft: 0,
    speed: 2.3 + Math.random() * 0.4,
    muzzleTimer: 0,
    hitTimer: 0,
  };
}

function setPatrolTarget(bot) {
  const anchor = coverAnchors[Math.floor(Math.random() * coverAnchors.length)] || new THREE.Vector3();
  const sign = bot.team === TEAM_FRIENDLY ? 1 : -1;
  bot.patrolTarget = new THREE.Vector3(anchor.x + (Math.random() - 0.5) * 3, 0, anchor.z + sign * (2 + Math.random() * 5));
}

function chooseCoverPosition(bot, threatPosition) {
  const sign = bot.team === TEAM_FRIENDLY ? 1 : -1;
  const anchors = coverAnchors.filter((anchor) => (bot.team === TEAM_FRIENDLY ? anchor.z > -1 : anchor.z < 1));
  if (!anchors.length) {
    return null;
  }
  return anchors.reduce((best, anchor) => {
    const hidePos = anchor.clone().add(new THREE.Vector3(0, 0, sign * 1.8));
    const score = bot.mesh.position.distanceTo(hidePos) + hidePos.distanceTo(threatPosition) * 0.35;
    if (!best || score < best.score) {
      return { score, position: hidePos };
    }
    return best;
  }, null)?.position || null;
}

function resetBots() {
  botState.forEach((bot) => scene.remove(bot.mesh));
  botState.length = 0;

  const friendSpawns = [
    new THREE.Vector3(-8, 0, 13),
    new THREE.Vector3(-3, 0, 11),
    new THREE.Vector3(3, 0, 11),
    new THREE.Vector3(8, 0, 13),
  ];
  const enemySpawns = [
    new THREE.Vector3(-7, 0, -12),
    new THREE.Vector3(-3, 0, -10),
    new THREE.Vector3(1, 0, -11),
    new THREE.Vector3(5, 0, -9),
    new THREE.Vector3(9, 0, -12),
  ];

  friendSpawns.forEach((spawn, index) => {
    const bot = makeBot(TEAM_FRIENDLY, index, spawn);
    setPatrolTarget(bot);
    botState.push(bot);
  });
  enemySpawns.forEach((spawn, index) => {
    const bot = makeBot(TEAM_ENEMY, index, spawn);
    setPatrolTarget(bot);
    botState.push(bot);
  });
}

function respawnBot(bot) {
  const spawns = bot.team === TEAM_FRIENDLY ? FRIEND_SPAWNS : ENEMY_SPAWNS;
  const spawn = spawns[Number(bot.id.split('-')[1])] || spawns[0] || new THREE.Vector3();
  bot.mesh.position.copy(spawn);
  bot.mesh.position.y = 0;
  bot.mesh.visible = true;
  bot.hp = 100;
  bot.alive = true;
  bot.state = 'patrol';
  bot.deadAt = 0;
  bot.respawnAt = 0;
  bot.cooldown = 400 + Math.random() * 800;
  bot.coverTarget = null;
  bot.burstLeft = 0;
  bot.hitTimer = 0;
  setPatrolTarget(bot);
}

function teamAliveCount(team) {
  let count = playerAlive && team === TEAM_FRIENDLY ? 1 : 0;
  botState.forEach((bot) => {
    if (bot.team === team && bot.alive) count += 1;
  });
  return count;
}

function teamRespawnPending(team) {
  let count = !playerAlive && team === TEAM_FRIENDLY && respawnTimer > 0 ? 1 : 0;
  botState.forEach((bot) => {
    if (bot.team === team && !bot.alive && bot.respawnAt > performance.now()) count += 1;
  });
  return count;
}

function notifyExternal(result) {
  const payload = { type: 'tamapet-voxel-fps-result', petId, petName, ...result };
  if (typeof window.voxelFpsGameCallback === 'function') {
    window.voxelFpsGameCallback(payload);
  }
  if (window.parent && window.parent !== window) {
    window.parent.postMessage(payload, '*');
  }
}

window.calculateCoins = function calculateCoins(kills, winStatus, timeAlive) {
  const participation = 4;
  const killScore = Math.min(8, kills * 2);
  const winBonus = winStatus ? 6 : 0;
  const survivalBonus = Math.min(4, Math.floor(timeAlive / 30));
  return Math.min(20, participation + killScore + winBonus + survivalBonus);
};

function playerCollision(nextPosition) {
  collisionBox.min.set(nextPosition.x - PLAYER_RADIUS, nextPosition.y - PLAYER_HEIGHT, nextPosition.z - PLAYER_RADIUS);
  collisionBox.max.set(nextPosition.x + PLAYER_RADIUS, nextPosition.y + 0.1, nextPosition.z + PLAYER_RADIUS);
  return colliders.some((box) => scratchBox.copy(box).intersectsBox(collisionBox));
}

function lineOfSight(from, to) {
  tempVecA.copy(to).sub(from);
  const distance = tempVecA.length();
  if (!distance) return true;
  raycaster.set(from, tempVecA.normalize());
  raycaster.far = distance;
  const hits = raycaster.intersectObjects(mapGroup.children, false);
  return hits.length === 0;
}

function findTarget(bot) {
  const candidates = [];
  if (bot.team === TEAM_ENEMY && playerAlive) {
    const playerPos = controls.getObject().position.clone();
    candidates.push({ type: 'player', position: playerPos, distance: bot.mesh.position.distanceTo(playerPos) });
  }
  botState.forEach((other) => {
    if (!other.alive || other.team === bot.team) return;
    candidates.push({ type: 'bot', bot: other, position: other.mesh.position, distance: bot.mesh.position.distanceTo(other.mesh.position) });
  });
  candidates.sort((a, b) => a.distance - b.distance);
  return candidates.find((entry) => entry.distance < 18 && lineOfSight(bot.mesh.position.clone().add(new THREE.Vector3(0, 1.2, 0)), entry.position.clone().add(new THREE.Vector3(0, 1.2, 0)))) || null;
}

function applyDamage(target, amount, attackerName) {
  if (target === 'player') {
    if (!playerAlive) return;
    playerHealth = Math.max(0, playerHealth - amount);
    healthEl.textContent = String(playerHealth);
    showHitMarker();
    damageFlashTimer = 220;
    damageScreen?.classList.add('is-active');
    setStatus(`中枪！生命降到 ${playerHealth}`);
    if (playerHealth <= 0) {
      playerAlive = false;
      controls.unlock();
      respawnTimer = PLAYER_RESPAWN_MS;
      respawnOverlay.hidden = false;
      respawnTitleEl.textContent = '你已倒下';
      respawnSummaryEl.textContent = '系统将在短暂时间后把你投回前线，也可以直接重新开始。';
      addKillfeed(`${attackerName} 击倒了你`);
      setStatus('你已倒下，等待本局结束。');
    }
    return;
  }

  if (!target.alive) return;
  target.hp = Math.max(0, target.hp - amount);
  target.hitTimer = 140;
  if (target.hp <= 0) {
    target.alive = false;
    target.state = 'dead';
    target.deadAt = performance.now();
    target.respawnAt = target.deadAt + BOT_RESPAWN_MS;
    addKillfeed(`${attackerName} 击倒了 ${target.team === TEAM_FRIENDLY ? '友军' : '敌军'} Bot`);
  }
}

function playerShoot(now) {
  if (!pointerLocked || !playerAlive || !gameRunning || now - lastPlayerShot < 150) {
    return;
  }
  lastPlayerShot = now;
  viewWeapon.userData.kick = 1;
  viewWeapon.userData.muzzle.visible = true;
  window.setTimeout(() => {
    viewWeapon.userData.muzzle.visible = false;
  }, 60);

  raycaster.setFromCamera(new THREE.Vector2(0, 0), camera);
  const enemyMeshes = botState.filter((bot) => bot.alive && bot.team === TEAM_ENEMY).map((bot) => bot.mesh);
  const hits = raycaster.intersectObjects(enemyMeshes, true);
  if (!hits.length) {
    return;
  }
  const hitMesh = hits[0].object;
  const bot = botState.find((entry) => entry.mesh === hitMesh.parent || entry.mesh.children.includes(hitMesh) || entry.mesh === hitMesh);
  if (!bot) {
    return;
  }
  bot.hp = Math.max(0, bot.hp - 34);
  bot.hitTimer = 180;
  showHitMarker();
  if (bot.hp <= 0) {
    bot.alive = false;
    bot.state = 'dead';
    bot.mesh.visible = false;
    playerKills += 1;
    killsEl.textContent = String(playerKills);
    addKillfeed(`你击倒了 ${bot.label || '敌军'}`);
  }
}

function updateViewWeapon(delta) {
  const kick = viewWeapon.userData.kick || 0;
  if (kick > 0) {
    viewWeapon.position.z = -0.75 + kick * 0.09;
    viewWeapon.rotation.x = -0.12 - kick * 0.05;
    viewWeapon.userData.kick = Math.max(0, kick - delta * 0.006);
  } else {
    viewWeapon.position.z = -0.75;
    viewWeapon.rotation.x = -0.12;
  }
}

function updateBots(delta) {
  botState.forEach((bot) => {
    if (!bot.alive) {
      if (bot.mesh.visible && performance.now() - bot.deadAt > 1200) {
        bot.mesh.visible = false;
      }
      if (!gameEnded && bot.respawnAt && performance.now() >= bot.respawnAt) {
        respawnBot(bot);
      }
      return;
    }
    bot.cooldown -= delta;
    bot.hitTimer = Math.max(0, bot.hitTimer - delta);
    bot.strafeTimer -= delta;

    const target = findTarget(bot);
    if (target) {
      const threatPos = target.position.clone();
      if (!bot.coverTarget || bot.mesh.position.distanceTo(bot.coverTarget) < 0.6) {
        bot.coverTarget = chooseCoverPosition(bot, threatPos);
      }

      if (bot.coverTarget && bot.mesh.position.distanceTo(bot.coverTarget) > 0.9) {
        bot.state = 'seek_cover';
        tempVecA.copy(bot.coverTarget).sub(bot.mesh.position);
        tempVecA.y = 0;
        if (tempVecA.lengthSq() > 0.01) {
          tempVecA.normalize().multiplyScalar(bot.speed * delta * 0.0011);
          tempVecB.copy(bot.mesh.position).add(tempVecA);
          if (!playerCollision(tempVecB.clone().setY(PLAYER_HEIGHT))) {
            bot.mesh.position.x = tempVecB.x;
            bot.mesh.position.z = tempVecB.z;
          }
          bot.mesh.lookAt(bot.coverTarget.x, 0.9, bot.coverTarget.z);
        }
        return;
      }

      bot.state = 'engage';
      tempVecA.copy(threatPos).sub(bot.mesh.position);
      tempVecA.y = 0;
      if (tempVecA.lengthSq() > 0.01) {
        bot.mesh.lookAt(bot.mesh.position.x + tempVecA.x, 0.9, bot.mesh.position.z + tempVecA.z);
      }
      if (target.distance > 8 && !bot.coverTarget) {
        tempVecA.normalize().multiplyScalar(bot.speed * delta * 0.001);
        tempVecB.copy(bot.mesh.position).add(tempVecA);
        if (!playerCollision(tempVecB.clone().setY(PLAYER_HEIGHT))) {
          bot.mesh.position.x = tempVecB.x;
          bot.mesh.position.z = tempVecB.z;
        }
      }

      if (bot.coverTarget) {
        if (bot.strafeTimer <= 0) {
          bot.strafeDir *= -1;
          bot.strafeTimer = 400 + Math.random() * 700;
        }
        const right = new THREE.Vector3().crossVectors(tempVecA.normalize(), new THREE.Vector3(0, 1, 0)).normalize();
        tempVecB.copy(bot.mesh.position).addScaledVector(right, bot.strafeDir * bot.speed * delta * 0.00035);
        if (!playerCollision(tempVecB.clone().setY(PLAYER_HEIGHT))) {
          bot.mesh.position.x = tempVecB.x;
          bot.mesh.position.z = tempVecB.z;
        }
      }

      if (bot.cooldown <= 0) {
        bot.cooldown = 550 + Math.random() * 450;
        bot.burstLeft = 1 + Math.floor(Math.random() * 3);
      }
      if (bot.burstLeft > 0 && bot.cooldown <= 120) {
        bot.cooldown = 160;
        bot.burstLeft -= 1;
        bot.mesh.userData.muzzle.visible = true;
        window.setTimeout(() => {
          if (bot.mesh.userData.muzzle) bot.mesh.userData.muzzle.visible = false;
        }, 80);
        applyDamage(target.type === 'player' ? 'player' : target.bot, 12, bot.team === TEAM_ENEMY ? '敌军 Bot' : '友军 Bot');
      }
      return;
    }

    bot.state = 'patrol';
    bot.coverTarget = null;
    if (bot.mesh.position.distanceTo(bot.patrolTarget) < 0.8) {
      setPatrolTarget(bot);
    }
    tempVecA.copy(bot.patrolTarget).sub(bot.mesh.position);
    tempVecA.y = 0;
    if (tempVecA.lengthSq() > 0.01) {
      tempVecA.normalize().multiplyScalar(bot.speed * delta * 0.0008);
      tempVecB.copy(bot.mesh.position).add(tempVecA);
      if (!playerCollision(tempVecB.clone().setY(PLAYER_HEIGHT))) {
        bot.mesh.position.x = tempVecB.x;
        bot.mesh.position.z = tempVecB.z;
        bot.mesh.lookAt(bot.patrolTarget.x, 0.9, bot.patrolTarget.z);
      } else {
        setPatrolTarget(bot);
      }
    }
  });
}

function updateBotAnimation(time) {
  botState.forEach((bot) => {
    if (!bot.mesh.visible) return;
    const parts = bot.mesh.userData;
    const stride = bot.state === 'patrol' || bot.state === 'engage' || bot.state === 'seek_cover' ? Math.sin(time * 0.008 + bot.mesh.position.x) : 0;
    parts.armL.rotation.x = stride * 0.8;
    parts.armR.rotation.x = -stride * 0.8;
    parts.legL.rotation.x = -stride * 0.9;
    parts.legR.rotation.x = stride * 0.9;
    if (bot.hitTimer > 0) {
      parts.body.material.emissive = new THREE.Color('#ffffff');
      parts.body.material.emissiveIntensity = 0.18;
    } else {
      parts.body.material.emissiveIntensity = 0;
    }
    if (bot.state === 'seek_cover') {
      parts.body.rotation.y = Math.sin(time * 0.01) * 0.08;
    } else {
      parts.body.rotation.y = 0;
    }
  });
}

function updatePlayerMovement(delta) {
  if ((!pointerLocked && !isMobileMode()) || !playerAlive) return;

  const moveSpeed = 7.4;
  const gravity = 22;
  const jumpSpeed = 8.6;
  const onGround = controls.getObject().position.y <= PLAYER_HEIGHT + 0.001;

  if (keyState.space && onGround) {
    playerVelocity.y = jumpSpeed;
  }

  playerVelocity.y -= gravity * delta;
  const direction = new THREE.Vector3();
  if (keyState.w) direction.z -= 1;
  if (keyState.s) direction.z += 1;
  if (keyState.a) direction.x -= 1;
  if (keyState.d) direction.x += 1;
  direction.x += mobileMoveVector.x;
  direction.z += mobileMoveVector.y;

  if (direction.lengthSq() > 0) {
    direction.normalize();
    controls.getDirection(tempVecB);
    tempVecB.y = 0;
    tempVecB.normalize();
    tempVecA.crossVectors(tempVecB, camera.up).normalize();

    const stepX = (tempVecA.x * direction.x + tempVecB.x * -direction.z) * moveSpeed * delta;
    const stepZ = (tempVecA.z * direction.x + tempVecB.z * -direction.z) * moveSpeed * delta;
    const current = controls.getObject().position;

    tempVecC.copy(current);
    tempVecC.x += stepX;
    if (!playerCollision(tempVecC)) {
      current.x = tempVecC.x;
    }

    tempVecC.copy(current);
    tempVecC.z += stepZ;
    if (!playerCollision(tempVecC)) {
      current.z = tempVecC.z;
    }
  }

  const nextY = controls.getObject().position.y + playerVelocity.y * delta;
  if (nextY <= PLAYER_HEIGHT) {
    controls.getObject().position.y = PLAYER_HEIGHT;
    playerVelocity.y = 0;
  } else {
    controls.getObject().position.y = nextY;
  }
}

function updateHud(remaining) {
  timerEl.textContent = String(Math.max(0, Math.ceil(remaining)));
  healthEl.textContent = String(Math.max(0, Math.round(playerHealth)));
  killsEl.textContent = String(playerKills);
  friendlyEl.textContent = String(teamAliveCount(TEAM_FRIENDLY));
  enemyEl.textContent = String(teamAliveCount(TEAM_ENEMY));
  const healthCard = healthEl.closest('.voxel-hud-block');
  if (healthCard) {
    healthCard.classList.toggle('is-danger', playerHealth <= 35);
  }
  if (!pointerLocked && gameRunning && playerAlive) {
    setStatus('鼠标已释放，点击开始战斗区域可继续锁定视角。');
  }
}

function endGame(winStatus) {
  if (gameEnded) return;
  gameEnded = true;
  gameRunning = false;
  gamePaused = false;
  controls.unlock();
  gameOverOverlay.hidden = false;
  respawnOverlay.hidden = true;
  pauseOverlay.hidden = true;

  const timeAlive = playerAlive ? ROUND_DURATION : Math.max(0, Math.floor((performance.now() - roundStart) / 1000));
  const localCoins = window.calculateCoins(playerKills, winStatus, timeAlive);
  const score = Math.min(100, localCoins * 5);

  endTitleEl.textContent = winStatus ? '友方获胜' : '战斗结束';
  endSummaryEl.textContent = `你击杀 ${playerKills} 人，存活时间 ${timeAlive} 秒，预计获得 ${localCoins} 金币。`;
  endKillsEl.textContent = String(playerKills);
  endTimeEl.textContent = `${timeAlive}s`;
  endCoinsEl.textContent = String(localCoins);

  const form = new FormData();
  form.set('game_type', 'voxel_fps');
  form.set('difficulty', 'normal');
  form.set('weapon', 'voxel_rifle');
  form.set('score', String(score));
  form.set('csrf_token', csrfToken);

  fetch(claimUrl, { method: 'POST', body: form, headers: { 'X-Requested-With': 'fetch' } })
    .then((response) => response.json())
    .then((data) => {
      const confirmedCoins = data.reward ?? localCoins;
      earnedCoins = confirmedCoins;
      endCoinsEl.textContent = String(confirmedCoins);
      setResultMessage(`${data.game_label || '方块战场'}结算完成：获得 ${confirmedCoins} 金币，当前剩余 ${data.coins_after ?? '-'} 金币。`, 'success');
      notifyExternal({ earnedCoins: confirmedCoins, kills: playerKills, winStatus, timeAlive });
    })
    .catch(() => {
      earnedCoins = localCoins;
      setResultMessage(`本地结算：预计获得 ${localCoins} 金币（接口异常，未能确认服务器奖励）。`, 'warning');
      notifyExternal({ earnedCoins: localCoins, kills: playerKills, winStatus, timeAlive });
    });
}

function resetRound() {
  playerHealth = 100;
  playerKills = 0;
  playerAlive = true;
  respawnTimer = 0;
  playerVelocity.set(0, 0, 0);
  controls.getObject().position.set(0, PLAYER_HEIGHT, 24);
  resetBots();
  hitMarker.classList.remove('is-active');
  hitMarkerTimer = 0;
  killfeed.innerHTML = '';
  gameRunning = false;
  gamePaused = false;
  gameEnded = false;
  roundStart = 0;
  lastPlayerShot = 0;
  setResultMessage('结算后会通过回调和金币接口把结果同步回主站。');
  gameOverOverlay.hidden = true;
  respawnOverlay.hidden = true;
  pauseOverlay.hidden = true;
  overlay.hidden = false;
  updateHud(ROUND_DURATION);
}

function respawnPlayer() {
  playerAlive = true;
  playerHealth = 100;
  respawnTimer = 0;
  damageFlashTimer = 0;
  damageScreen?.classList.remove('is-active');
  controls.getObject().position.set(0, PLAYER_HEIGHT, 24);
  respawnOverlay.hidden = true;
  setStatus('你已复活，重新投入战场。');
  healthEl.textContent = '100';
  if (!gameEnded) {
    gamePaused = false;
    controls.lock();
  }
}

function animate(now) {
  const delta = Math.min(0.05, (now - lastFrame) / 1000 || 0);
  lastFrame = now;

  if (gameRunning && !gamePaused) {
    const elapsedSeconds = (now - roundStart) / 1000;
    const remaining = ROUND_DURATION - elapsedSeconds;

    updatePlayerMovement(delta);
    updateBots(delta * 1000);
    updateBotAnimation(now);
    updateViewWeapon(delta * 1000);

    if (hitMarkerTimer > 0) {
      hitMarkerTimer -= delta * 1000;
      if (hitMarkerTimer <= 0) hitMarker.classList.remove('is-active');
    }
    if (damageFlashTimer > 0) {
      damageFlashTimer -= delta * 1000;
      if (damageFlashTimer <= 0) {
        damageScreen?.classList.remove('is-active');
      }
    }
    if (!playerAlive && respawnTimer > 0 && !gameEnded) {
      respawnTimer -= delta * 1000;
      respawnTitleEl.textContent = `你已倒下 - ${Math.max(1, Math.ceil(respawnTimer / 1000))} 秒后复活`;
      if (respawnTimer <= 0) {
        respawnPlayer();
      }
    }

    updateHud(remaining);

    if (
      remaining <= 0 ||
      (teamAliveCount(TEAM_FRIENDLY) <= 0 && teamRespawnPending(TEAM_FRIENDLY) <= 0) ||
      (teamAliveCount(TEAM_ENEMY) <= 0 && teamRespawnPending(TEAM_ENEMY) <= 0)
    ) {
      endGame(teamAliveCount(TEAM_FRIENDLY) > teamAliveCount(TEAM_ENEMY));
    }
  } else if (gameRunning && gamePaused) {
    updateHud(Math.max(0, ROUND_DURATION - (performance.now() - roundStart) / 1000));
  }

  renderer.render(scene, camera);
  requestAnimationFrame(animate);
}

function resize() {
  const width = stage.clientWidth;
  const height = stage.clientHeight;
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  renderer.setSize(width, height, false);
}

async function toggleFullscreen() {
  if (document.fullscreenElement !== stage) {
    await stage.requestFullscreen();
    fullscreenButton.textContent = '退出全屏';
  } else {
    await document.exitFullscreen();
    fullscreenButton.textContent = '进入全屏';
  }
}

function updateStick(clientX, clientY) {
  const rect = stickZone.getBoundingClientRect();
  const cx = rect.left + rect.width / 2;
  const cy = rect.top + rect.height / 2;
  const dx = clientX - cx;
  const dy = clientY - cy;
  const max = rect.width * 0.28;
  const len = Math.hypot(dx, dy) || 1;
  const clampedLen = Math.min(max, len);
  const nx = (dx / len) * clampedLen;
  const ny = (dy / len) * clampedLen;
  stickThumb.style.transform = `translate(calc(-50% + ${nx}px), calc(-50% + ${ny}px))`;
  mobileMoveVector.set(nx / max, ny / max);
}

function resetStick() {
  mobileMoveVector.set(0, 0);
  stickThumb.style.transform = 'translate(-50%, -50%)';
}

function buildWorldDecor() {
  const grid = new THREE.GridHelper(34, 34, 0x5d7a4f, 0x5d7a4f);
  grid.position.y = 0.01;
  grid.material.opacity = 0.22;
  grid.material.transparent = true;
  scene.add(grid);
}

createArena();
buildWorldDecor();
resetRound();
resize();
requestAnimationFrame(animate);

window.addEventListener('resize', resize);

controls.addEventListener('lock', () => {
  pointerLocked = true;
  setPaused(false);
  setStatus('已锁定鼠标，开始战斗。');
});
controls.addEventListener('unlock', () => {
  pointerLocked = false;
  clearMovementState();
  if (gameRunning && !gameEnded && playerAlive && !respawnOverlay.hidden) {
    return;
  }
  if (gameRunning && !gameEnded && playerAlive) {
    setPaused(true, '你按下了 Esc，战斗已暂停。点击继续游戏可回到战斗。');
  }
});

startButton.addEventListener('click', () => {
  resetRound();
  gameRunning = true;
  roundStart = performance.now();
  overlay.hidden = true;
  focusGamePage();
  if (!isMobileMode()) {
    controls.lock();
  } else {
    setStatus('触屏模式已启动：左手移动，右侧滑屏瞄准，右下角开火。');
  }
});

restartButton.addEventListener('click', () => {
  resetRound();
  gameRunning = true;
  roundStart = performance.now();
  overlay.hidden = true;
  focusGamePage();
  if (!isMobileMode()) {
    controls.lock();
  } else {
    setStatus('触屏模式已启动：左手移动，右侧滑屏瞄准，右下角开火。');
  }
});

forceRestartButton?.addEventListener('click', () => {
  resetRound();
  gameRunning = true;
  roundStart = performance.now();
  overlay.hidden = true;
  respawnOverlay.hidden = true;
  focusGamePage();
  if (!isMobileMode()) {
    controls.lock();
  }
});

fullscreenButton?.addEventListener('click', () => {
  toggleFullscreen();
});

resumeButton?.addEventListener('click', () => {
  setPaused(false);
  focusGamePage();
  if (!isMobileMode()) {
    controls.lock();
  } else {
    setStatus('触屏模式已恢复，继续战斗。');
  }
});

document.addEventListener('fullscreenchange', () => {
  if (fullscreenButton) {
    fullscreenButton.textContent = document.fullscreenElement === stage ? '退出全屏' : '进入全屏';
  }
  if (document.fullscreenElement !== stage && gameRunning && !gameEnded && playerAlive) {
    clearMovementState();
    setPaused(true, '你已退出全屏，战斗已自动暂停。点击继续游戏恢复。');
    if (pointerLocked) {
      controls.unlock();
    }
  }
});

function handleKeyDown(event) {
  if (event.code === 'Escape' && gameRunning && !gameEnded && playerAlive && !gamePaused) {
    setPaused(true, '你按下了 Esc，战斗已暂停。点击继续游戏可回到战斗。');
    if (pointerLocked) {
      controls.unlock();
    }
    return;
  }
  setMovementKey(event, true);
}

function handleKeyUp(event) {
  setMovementKey(event, false);
}

document.addEventListener('keydown', handleKeyDown);
document.addEventListener('keyup', handleKeyUp);
window.addEventListener('keydown', handleKeyDown);
window.addEventListener('keyup', handleKeyUp);
window.addEventListener('blur', clearMovementState);
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    clearMovementState();
  }
});

document.addEventListener('mousedown', (event) => {
  if (event.button !== 0) return;
  if (!gameRunning || !pointerLocked) return;
  playerShoot(performance.now());
});

stickZone?.addEventListener('pointerdown', (event) => {
  if (!isMobileMode()) return;
  mobileMoveId = event.pointerId;
  updateStick(event.clientX, event.clientY);
});

mobileFireButton?.addEventListener('pointerdown', (event) => {
  event.preventDefault();
  if (!gameRunning || !playerAlive) return;
  playerShoot(performance.now());
});

stage.addEventListener('pointerdown', (event) => {
  if (!isMobileMode()) return;
  if (stickZone?.contains(event.target) || mobileFireButton?.contains(event.target)) return;
  mobileLookId = event.pointerId;
  mobileLookLast = { x: event.clientX, y: event.clientY };
});

stage.addEventListener('pointermove', (event) => {
  if (isMobileMode()) {
    if (mobileMoveId === event.pointerId) {
      updateStick(event.clientX, event.clientY);
      return;
    }
    if (mobileLookId === event.pointerId && mobileLookLast) {
      const dx = event.clientX - mobileLookLast.x;
      const dy = event.clientY - mobileLookLast.y;
      controls.getObject().rotation.y -= dx * 0.004;
      camera.rotation.x = Math.max(-1.2, Math.min(1.2, camera.rotation.x - dy * 0.004));
      mobileLookLast = { x: event.clientX, y: event.clientY };
    }
  }
});

stage.addEventListener('pointerup', (event) => {
  if (mobileMoveId === event.pointerId) {
    mobileMoveId = null;
    resetStick();
  }
  if (mobileLookId === event.pointerId) {
    mobileLookId = null;
    mobileLookLast = null;
  }
});
